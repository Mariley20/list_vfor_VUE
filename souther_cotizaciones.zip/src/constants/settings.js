/* Constantes de licitaciones */
export const DOWNLOAD_DATE = ' Fecha de descarga '

/* Constantes de proveedores */
export const PREVIOUS_NET_WORTH = ' Valor neto anterior '
export const FREIGHT_COST = ' Costo de flete '
export const FACTOR_LANDED = ' Costo de flete '
export const FINAL_FULL_VALUE = ' Valor total final '
export const FULL_OFFER_VALUE = ' Valor Total de la Oferta '

/* Constantes de productos */
export const SHORT_TEXT = ' Texto Breve '
export const DELIVERY_DAYS = ' Dias de entrega '
export const NET_WORTH = ' Valor neto '
export const UNIT = ' Unidad '
export const NET_PRICE = ' Precio neto '
export const LANDED_PRICE = 'Precio Landed'
export const AMOUNT = ' Cantidad '
