<template>
  <tr>
    <td>
      <!--  -->
    </td>
  </tr>
</template>

<script>
export default {
  props: {
    row: { type: Array, default: () => [] }
  }
}
</script>

<style lang="scss" scoped>

</style>
